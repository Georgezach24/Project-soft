package gr.conference.menus;

import java.util.Scanner;

import javax.swing.JOptionPane;

import gr.conference.usersys.RestClient;

public class AdminSettingsPage {
	public AdminSettingsPage()
	{
		loadPage();
	}
	
	private void loadPage()
	{
		int flag = 0;
		
		
		JOptionPane.showMessageDialog(null,("-----------------------------"));
		JOptionPane.showMessageDialog(null,("1. Information update"));
		JOptionPane.showMessageDialog(null,("2. Password update"));
		JOptionPane.showMessageDialog(null,("3. Delete Account"));
		JOptionPane.showMessageDialog(null,("4. Account status update"));
		JOptionPane.showMessageDialog(null,("5. Back"));
		JOptionPane.showMessageDialog(null,(">"));
		int input = Integer.parseInt(JOptionPane.showInputDialog(null));
		JOptionPane.showMessageDialog(null,("-----------------------------"));
		
		while(flag ==0)
		{
			switch (input)
			{
				case 1:
					flag = 1;
					infoUpdate();
					break;
				case 2:
					flag = 1;
					passwordUpdate();
					break;
				case 3:
					flag = 1;
					deleteAccount();
					break;
				case 4:
					flag = 1;
					statusUpdate();
					break;
				case 5:
					flag = 1;
					AdminPage ap = new AdminPage();
					break;
				default:
					flag = 1;
					loadPage();
					break;
			}
			
		}
		
		AdminPage ap = new AdminPage();
	}
	
	private String infoUpdate()
	{
		
		
		RestClient.updateRequest();
		JOptionPane.showMessageDialog(null,("Write the current username: "));
		String username = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Write the new username: "));
		String usernameString = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Write the new Name: "));
		String nameString = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Write the new Surname: "));
		String surnameString = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Write the new Email: "));
		String emailString = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Write the new Phone: "));
		String phoneString = JOptionPane.showInputDialog(null);
		
		RestClient.updatePost(username, usernameString, nameString, surnameString, emailString, phoneString);
		
		return usernameString;
		
	}
	
	private void passwordUpdate()
	{
		
		
		RestClient.passwordUpdateRequest();
		JOptionPane.showMessageDialog(null,("Write the username: "));
		String username = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null ,("Write the old password: "));
		String oldPassword = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Write the new password: "));
		String newPassword = JOptionPane.showInputDialog(null);
		
		RestClient.passwordUpdatePost(username , oldPassword, newPassword);
	}
	
	private void deleteAccount()
	{
		
		
		RestClient.deleteRequest();
		JOptionPane.showMessageDialog(null,("Write the username: "));
		String username = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Are you sure you want to delete this account?(y/n)"));
		JOptionPane.showMessageDialog(null,(">"));
		String input = JOptionPane.showInputDialog(null);
		
		if(input.equals("y") || input.equals("Y"))
		{
			RestClient.deletePost(username);
		}
	}
	
	private void statusUpdate()
	{
		
		RestClient.updateStatusRequest();
		JOptionPane.showMessageDialog(null,("Write the username: "));
		String username = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Write the status(ACTIVE/INACTIVE): "));
		String status = JOptionPane.showInputDialog(null);
		RestClient.updateStatusPost(username, status);
	}
}

