package gr.conference.menus;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class StartingScreen {
	
	public String user;
	
	public StartingScreen()
	{
		loadMenu();
	}
	
	private void loadMenu()
	{
		
		int flag = 0;
		LoginPage lp = new LoginPage();
		
		JOptionPane.showMessageDialog(null,("------------------------------------------"));
		JOptionPane.showMessageDialog(null,("WELCOME TO THE CONFERENCE SYSTEM USER PAGE"));
		while(flag == 0)
		{
			JOptionPane.showMessageDialog(null,("1. LOGIN"));
			JOptionPane.showMessageDialog(null,("2. REGISTER"));
			JOptionPane.showMessageDialog(null,("3. CONTINUE AS GUEST"));
			JOptionPane.showMessageDialog(null,("4. EXIT"));
			JOptionPane.showMessageDialog(null,("Your input >"));
			int input = Integer.parseInt(JOptionPane.showInputDialog(null));
		
		
			switch(input)
			{
				case 1:
					flag = 1;
					lp.loadPageUser();
					break;
				case 2:
					flag = 1;
					RegisterPage rp = new RegisterPage();
					break;
				case 3:
					flag = 1;
					//TODO Φτιάξε τι θα γίνεται σε περίπτωση visitor.
					break;	
				case 4:
					flag = 1;
					System.exit(0);
					break;
				default:
					flag = 0;
					break;
			}
		}
		
	}

	public String getUser() {
		return user;
	}
	
}
