package gr.conference.menus;

import java.util.Scanner;

import javax.swing.JOptionPane;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import gr.conference.usersys.RestClient;
import gr.conference.usersys.UserDBHandler;

public class LoginPage {

    public String username;

    // Method to load the user login page
    public void loadPageUser() {
        
        String username_local = "";
        
        // Loop until loginTries is 0 or the user logs in successfully
        while (UserDBHandler.loginTries != 0) {
            JOptionPane.showMessageDialog(null,("Username: "));
            username_local = JOptionPane.showInputDialog(null);
            JOptionPane.showMessageDialog(null,("Password: "));
            String password = JOptionPane.showInputDialog(null);

            // Call RestClient to handle user login
            String ret = RestClient.loginPost(username_local, password);
            
            // Parse the response using Gson
            JsonObject response = new Gson().fromJson(ret, JsonObject.class);
            String responseCode = response.get("responseCode").getAsString();
            String responseMessage = response.get("responseMessage").getAsString();

            // Check if login was successful
            if (responseCode.equals("200")) {
                JOptionPane.showMessageDialog(null,(responseMessage)); // Success message
                username = username_local;
                UserPage uPage = new UserPage(username);
                break;
            } else {
                JOptionPane.showMessageDialog(null,("Login failed. Try again."));
                UserDBHandler.loginTries--; // Decrement tries on failure
            }
        }

        if (UserDBHandler.loginTries == 0) {
            JOptionPane.showMessageDialog(null,("Too many failed attempts. Access denied."));
            StartingScreen ss = new StartingScreen();        }

    }

    // Method to load the admin login page
    public void loadPageAdmin() {
        
        String username_local = "";
        
        // Loop until loginTries is 0 or the admin logs in successfully
        while (UserDBHandler.loginTries != 0) {
            JOptionPane.showMessageDialog(null,("Username: "));
            username_local = JOptionPane.showInputDialog(null);
            JOptionPane.showMessageDialog(null,("Password: "));
            String password = JOptionPane.showInputDialog(null);

            // Call RestClient to handle admin login
            String ret = RestClient.loginPost(username_local, password); // Use unified login for both admin and users
            
            // Parse the response using Gson
            JsonObject response = new Gson().fromJson(ret, JsonObject.class);
            String responseCode = response.get("responseCode").getAsString();
            String responseMessage = response.get("responseMessage").getAsString();

            // Check if login was successful
            if (responseCode.equals("200")) {
                JOptionPane.showMessageDialog(null,(responseMessage)); // Success message
                AdminPage ap = new AdminPage();
                break;
            } else {
                JOptionPane.showMessageDialog(null,("Admin login failed. Try again."));
                UserDBHandler.loginTries--; // Decrement tries on failure
            }
        }

        if (UserDBHandler.loginTries == 0) {
            JOptionPane.showMessageDialog(null,("Too many failed attempts. Access denied."));
        }


    }
}
