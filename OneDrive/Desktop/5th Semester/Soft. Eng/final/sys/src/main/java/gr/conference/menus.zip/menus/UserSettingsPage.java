package gr.conference.menus;

import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.JOptionPane;

import gr.conference.usersys.RestClient;

public class UserSettingsPage {

    public UserSettingsPage(String usernameString) {
        loadPage(usernameString);
    }

    private void loadPage(String username) {
        
        boolean flag = false;

        while (!flag) {
            try {
                JOptionPane.showMessageDialog(null,("-----------------------------"));
                JOptionPane.showMessageDialog(null,("1. Information update"));
                JOptionPane.showMessageDialog(null,("2. Password update"));
                JOptionPane.showMessageDialog(null,("3. Delete Account"));
                JOptionPane.showMessageDialog(null,("4. Back"));
                JOptionPane.showMessageDialog(null,(">"));
                int input = Integer.parseInt(JOptionPane.showInputDialog(null));
                JOptionPane.showInputDialog(null); // Consume the newline character
                JOptionPane.showMessageDialog(null,("-----------------------------"));

                switch (input) {
                    case 1:
                        username = infoUpdate(username); // Update username if changed
                        break;
                    case 2:
                        passwordUpdate(username);
                        break;
                    case 3:
                        deleteAccount(username);
                        new StartingScreen(); // Go back to the starting screen after account deletion
                        flag = true;
                        return;
                    case 4:
                        flag = true;
                        new UserPage(username); // Go back to the user page
                        return;
                    default:
                        JOptionPane.showMessageDialog(null,("Invalid option. Please try again."));
                }
            } catch (InputMismatchException e) {
                JOptionPane.showMessageDialog(null,("Invalid input. Please enter a number between 1 and 4."));
                JOptionPane.showInputDialog(null); // Clear invalid input
            }
        }

    }

    private String infoUpdate(String username) {
        // No need to call RestClient.updateRequest() as it's not functional
        JOptionPane.showMessageDialog(null,("Updating Information:"));

        JOptionPane.showMessageDialog(null,("Write your new username: "));
        String newUsername = JOptionPane.showInputDialog(null);
        JOptionPane.showMessageDialog(null,("Write your new Name: "));
        String newName = JOptionPane.showInputDialog(null);
        JOptionPane.showMessageDialog(null,("Write your new Surname: "));
        String newSurname = JOptionPane.showInputDialog(null);
        JOptionPane.showMessageDialog(null,("Write your new Email: "));
        String newEmail = JOptionPane.showInputDialog(null);
        JOptionPane.showMessageDialog(null,("Write your new Phone: "));
        String newPhone = JOptionPane.showInputDialog(null);

        // Call RestClient to update user info
        RestClient.updatePost(username, newUsername, newName, newSurname, newEmail, newPhone);

        // If the username has changed, return the new username
        return newUsername.isBlank() ? username : newUsername;
    }

    private void passwordUpdate(String username) {
        // No need to call RestClient.passwordUpdateRequest() as it's not functional
        JOptionPane.showMessageDialog(null,("Updating Password:"));
        JOptionPane.showMessageDialog(null,("Write your old password: "));
        String oldPassword = JOptionPane.showInputDialog(null);
        JOptionPane.showMessageDialog(null,("Write your new password: "));
        String newPassword = JOptionPane.showInputDialog(null);

        // Call RestClient to update the password
        RestClient.passwordUpdatePost(username, oldPassword, newPassword);
    }

    private void deleteAccount(String username) {
        // No need to call RestClient.deleteRequest() as it's not functional
        JOptionPane.showMessageDialog(null,("Are you sure you want to delete your account? (y/n)"));
        JOptionPane.showMessageDialog(null,(">"));

        String input = JOptionPane.showInputDialog(null);
        if (input.equalsIgnoreCase("y")) {
            RestClient.deletePost(username);
            JOptionPane.showMessageDialog(null,("Your account has been deleted."));
        } else {
            JOptionPane.showMessageDialog(null,("Account deletion canceled."));
        }
    }
}
