package gr.conference.menus;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class AdminPage {
	
	public AdminPage()
	{
		loadPage();
	}
	
	private void loadPage()
	{
		int flag = 0;
		
		
		JOptionPane.showMessageDialog(null,("--------------------\nWELCOME ADMIN\n--------------------\n1. Admin settings"));
		JOptionPane.showMessageDialog(null,("2. Create new conference"));
		JOptionPane.showMessageDialog(null,("3. "));
		JOptionPane.showMessageDialog(null,(">"));
		int input = Integer.parseInt(JOptionPane.showInputDialog(null));
		
		while (flag == 0) 
		{
			switch (input) {
			case 1: 
				flag = 1;
				AdminSettingsPage asp = new AdminSettingsPage();
				break;
			
			default:
				flag = 1;
				loadPage();
				break;
			}	
		}
	}
}
