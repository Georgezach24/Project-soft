package gr.conference.menus;

import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

import gr.conference.confsys.Conference;
import gr.conference.confsys.RestClient;

public class ConferenceSearchPage {
	public ConferenceSearchPage(String username)
	{
		loadPage(username);
	}
	
	private void loadPage(String username)
	{
		
		
		RestClient.confSearchRequest();
		JOptionPane.showMessageDialog(null,("Conference name: "));
		String name = JOptionPane.showInputDialog(null);
		JOptionPane.showMessageDialog(null,("Conference description: "));
		String desc = JOptionPane.showInputDialog(null);
		List <Conference> searchRes = RestClient.confSearchPost(name,desc);
		
		if(!searchRes.isEmpty())
		{
			JOptionPane.showMessageDialog(null,(searchRes));
			UserPage up = new UserPage(username);
		}
		else
		{
			UserPage up = new UserPage(username);
		}
		
	}
}
