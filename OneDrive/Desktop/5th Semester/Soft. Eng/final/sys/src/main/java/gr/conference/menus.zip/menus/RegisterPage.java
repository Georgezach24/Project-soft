package gr.conference.menus;

import java.util.Arrays;
import java.util.Scanner;

import javax.swing.JOptionPane;

import gr.conference.usersys.*;

import java.io.Console;

public class RegisterPage {
	public RegisterPage()
	{
		loadPage();
	}
	
	private void loadPage() {
	    
	    RestClient.registerRequest();

	    JOptionPane.showMessageDialog(null,("Username: "));
	    String username = JOptionPane.showInputDialog(null);

	    JOptionPane.showMessageDialog(null,("Password: "));
	    String password = readPasswordFromConsole();

	    JOptionPane.showMessageDialog(null,("Rewrite Password: "));
	    String password_conf = readPasswordFromConsole();

	    JOptionPane.showMessageDialog(null,("Email: "));
	    String email = JOptionPane.showInputDialog(null);

	    JOptionPane.showMessageDialog(null,("Phone: "));
	    String phone = JOptionPane.showInputDialog(null);

	    RestClient.registerPost(username, password, password_conf, email, phone);

	    

	    StartingScreen ss = new StartingScreen();//Επιστροφή στην αρχική.
	    
	}

	private String readPasswordFromConsole() 
	{
	    Console console = System.console();
	    if (console != null) {
	        char[] passwordChars = console.readPassword();
	        return new String(passwordChars);
	    } else {
	        // Fallback for environments where console is not available
	        
	        return JOptionPane.showInputDialog(null);
	    }
	}

			
}
