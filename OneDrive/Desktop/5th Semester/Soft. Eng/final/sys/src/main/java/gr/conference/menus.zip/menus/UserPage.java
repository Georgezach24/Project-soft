package gr.conference.menus;

import java.util.Scanner;

import javax.swing.JOptionPane;

import jakarta.validation.constraints.Pattern.Flag;

public class UserPage {
	public UserPage(String usernameString)
	{
		loadPage(usernameString);
	}
	
	private void loadPage(String uString)
	{
		int flag = 0;
		
		
		JOptionPane.showMessageDialog(null,("--------------------"));
		JOptionPane.showMessageDialog(null,("WELCOME " + uString.toUpperCase()));
		JOptionPane.showMessageDialog(null,("--------------------"));
		JOptionPane.showMessageDialog(null,("1. User settings"));
		JOptionPane.showMessageDialog(null,("2. Create new conference"));
		JOptionPane.showMessageDialog(null,("3. Conference search"));
		JOptionPane.showMessageDialog(null,("4. "));
		JOptionPane.showMessageDialog(null,(">"));
		int input = Integer.parseInt(JOptionPane.showInputDialog(null));
		
		while (flag == 0) 
		{
			switch (input) {
			case 1: 
				flag = 1;
				UserSettingsPage userSettingsPage = new UserSettingsPage(uString);
				break;
			case 2:
				flag = 1;
				ConferenceCreatePage ccp = new ConferenceCreatePage(uString);
				break;
			case 3:
				flag = 1;
				ConferenceSearchPage csp = new ConferenceSearchPage(uString);
				break;
			default:
				flag = 1;
				loadPage(uString);
				break;
			}	
		}
	}
}
