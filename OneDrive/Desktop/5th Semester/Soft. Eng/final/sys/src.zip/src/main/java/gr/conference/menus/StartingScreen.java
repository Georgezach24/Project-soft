package gr.conference.menus;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class StartingScreen {

    private JFrame frame;
    private JTextField inputField;
    private JLabel outputLabel;
    public String user;

    public StartingScreen() {
        loadMenu();
    }

    private void loadMenu() {
        // Δημιουργία παραθύρου (JFrame)
        frame = new JFrame("Conference System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        // Κεντρικό Panel με τις επιλογές
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(6, 1));

        // Προσθήκη επιλογών με JLabel
        menuPanel.add(new JLabel("WELCOME TO THE CONFERENCE SYSTEM USER PAGE", JLabel.CENTER));
        menuPanel.add(new JLabel("1. LOGIN", JLabel.CENTER));
        menuPanel.add(new JLabel("2. REGISTER", JLabel.CENTER));
        menuPanel.add(new JLabel("3. CONTINUE AS GUEST", JLabel.CENTER));
        menuPanel.add(new JLabel("4. EXIT", JLabel.CENTER));
        outputLabel = new JLabel("", JLabel.CENTER); // Για την έξοδο μηνυμάτων
        menuPanel.add(outputLabel);

        // Προσθήκη του Panel στο κέντρο του παραθύρου
        frame.add(menuPanel, BorderLayout.CENTER);

        // Πεδίο εισαγωγής στο κάτω μέρος (input field)
        inputField = new JTextField();
        inputField.setHorizontalAlignment(JTextField.CENTER);

        // Προσθήκη ActionListener για το Enter στο πεδίο εισαγωγής
        inputField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleUserInput(inputField.getText());
                inputField.setText(""); // Καθαρισμός του πεδίου μετά την είσοδο
            }
        });

        // Προσθήκη του πεδίου εισαγωγής στο κάτω μέρος του παραθύρου
        frame.add(inputField, BorderLayout.SOUTH);

        // Εμφάνιση του παραθύρου
        frame.setVisible(true);
    }

    // Μέθοδος για την επεξεργασία της εισόδου του χρήστη
    private void handleUserInput(String input) {
        int choice;
        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            outputLabel.setText("Invalid input! Please enter a valid number.");
            return;
        }

        LoginPage lp = new LoginPage();

        switch (choice) {
            case 1:
                // Επιλογή LOGIN
                lp.loadPageUser();
                frame.dispose(); // Κλείσιμο παραθύρου
                break;
            case 2:
                // Επιλογή REGISTER
                new RegisterPage();
                frame.dispose(); // Κλείσιμο παραθύρου
                break;
            case 3:
                // TODO: Λογική για Guest
                outputLabel.setText("Continuing as guest...");
                frame.dispose();
                break;
            case 4:
                // Έξοδος από την εφαρμογή
                System.exit(0);
                break;
            default:
                outputLabel.setText("Invalid option! Please select a valid option.");
                break;
        }
    }

    public String getUser() {
        return user;
    }
}
