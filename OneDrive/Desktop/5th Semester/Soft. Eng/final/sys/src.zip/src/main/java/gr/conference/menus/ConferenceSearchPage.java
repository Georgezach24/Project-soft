package gr.conference.menus;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;

import gr.conference.confsys.Conference;
import gr.conference.confsys.RestClient;

public class ConferenceSearchPage {

    private JFrame frame;
    private JTextField nameField;
    private JTextField descField;
    private JTextArea resultArea;

    public ConferenceSearchPage(String username) {
        initialize(username);
    }

    private void initialize(String username) {
        // Δημιουργία παραθύρου (JFrame)
        frame = new JFrame("Search Conference");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLayout(new BorderLayout());

        // Πάνω Panel με τα πεδία αναζήτησης
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new GridLayout(4, 2));

        // Ετικέτες και πεδία εισαγωγής για το όνομα και την περιγραφή του συνεδρίου
        JLabel nameLabel = new JLabel("Conference Name: ");
        nameField = new JTextField();

        JLabel descLabel = new JLabel("Conference Description: ");
        descField = new JTextField();

        searchPanel.add(nameLabel);
        searchPanel.add(nameField);
        searchPanel.add(descLabel);
        searchPanel.add(descField);

        // Κουμπί Αναζήτησης
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchConferences(username);
            }
        });

        searchPanel.add(new JLabel()); // Κενό για ευθυγράμμιση
        searchPanel.add(searchButton);

        // Περιοχή εμφάνισης των αποτελεσμάτων
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        // Προσθήκη των στοιχείων στο παράθυρο
        frame.add(searchPanel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Κουμπί επιστροφής
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Κλείσιμο παραθύρου
                new UserPage(username); // Επιστροφή στη σελίδα χρήστη
            }
        });

        frame.add(backButton, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    // Μέθοδος για αναζήτηση συνεδρίων
    private void searchConferences(String username) {
        String name = nameField.getText();
        String desc = descField.getText();

        // Κλήση του RestClient για την αναζήτηση
        RestClient.confSearchRequest();
        List<Conference> searchResults = RestClient.confSearchPost(name, desc);

        if (!searchResults.isEmpty()) {
            // Εμφάνιση των αποτελεσμάτων στην περιοχή κειμένου
            StringBuilder resultText = new StringBuilder("Search Results:\n");
            for (Conference conf : searchResults) {
                resultText.append("Name: ").append(conf.getName()).append("\n");
                resultText.append("Description: ").append(conf.getDesc()).append("\n");
                resultText.append("Date: ").append(conf.getDate()).append("\n\n");
            }
            resultArea.setText(resultText.toString());
        } else {
            resultArea.setText("No conferences found.");
        }
    }
}
