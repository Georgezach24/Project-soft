package gr.conference.menus;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import gr.conference.papersys.RestClient;

public class ConferencePage {

    private JFrame frame;
    private JTextField inputField;
    private JLabel outputLabel;

    public ConferencePage(String username, String confName) {
        initialize(username, confName);
    }

    private void initialize(String username, String confName) {
        // Δημιουργία παραθύρου (JFrame)
        frame = new JFrame("Conference: " + confName);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300); // Μέγεθος παραθύρου
        frame.setLayout(new BorderLayout());

        // Κεντρικό Panel με τις επιλογές
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(4, 1));

        // Προσθήκη μηνύματος καλωσορίσματος και επιλογών
        JLabel welcomeLabel = new JLabel(username.toUpperCase() + " you are inside conference: " + confName.toUpperCase(), JLabel.CENTER);
        JLabel label1 = new JLabel("1. Update conference info", JLabel.CENTER);
        JLabel label2 = new JLabel("2. Create new Paper", JLabel.CENTER);
        JLabel label3 = new JLabel("3. Back", JLabel.CENTER);

        // Πεδίο για εμφάνιση εξόδου
        outputLabel = new JLabel("", JLabel.CENTER);

        // Προσθήκη όλων των στοιχείων στο Panel
        menuPanel.add(welcomeLabel);
        menuPanel.add(label1);
        menuPanel.add(label2);
        menuPanel.add(label3);

        // Προσθήκη Panel και πεδίου εξόδου στο παράθυρο
        frame.add(menuPanel, BorderLayout.CENTER);
        frame.add(outputLabel, BorderLayout.NORTH);

        // Πεδίο εισαγωγής στο κάτω μέρος (input field)
        inputField = new JTextField();
        inputField.setHorizontalAlignment(JTextField.CENTER);
        inputField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleUserInput(inputField.getText(), username, confName);
                inputField.setText(""); // Καθαρισμός του πεδίου μετά την εισαγωγή
            }
        });

        frame.add(inputField, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    // Μέθοδος για την επεξεργασία της εισόδου του χρήστη
    private void handleUserInput(String input, String username, String confName) {
        int choice;
        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            outputLabel.setText("Invalid input! Please enter a number.");
            return;
        }

        switch (choice) {
            case 1:
                outputLabel.setText("Updating conference info...");
                updateInfo(confName, username);
                break;
            case 2:
                outputLabel.setText("Creating new paper...");
                createPaper(confName, username);
                break;
            case 3:
                outputLabel.setText("Going back...");
                frame.dispose(); // Κλείσιμο παραθύρου
                new UserPage(username); // Επιστροφή στη σελίδα χρήστη
                break;
            default:
                outputLabel.setText("Invalid choice! Please select a valid option.");
                break;
        }
    }

    // Μέθοδος για ενημέρωση πληροφοριών συνεδρίου
    private void updateInfo(String confName, String username) {
        // Λήψη νέων δεδομένων για το συνέδριο
        RestClient.confUpdateRequest();
        String newName = JOptionPane.showInputDialog(frame, "Insert new conference name:");
        String desc = JOptionPane.showInputDialog(frame, "Insert new conference description:");
        RestClient.confUpdatePost(confName, newName, desc);
        outputLabel.setText("Conference information updated successfully.");
    }

    // Μέθοδος για δημιουργία νέας εργασίας
    private void createPaper(String confName, String username) {
        // Λήψη δεδομένων για την εργασία
        String paperTitle = JOptionPane.showInputDialog(frame, "Insert Paper title:");
        String paperAbstract = JOptionPane.showInputDialog(frame, "Insert Paper abstract:");
        String paperContent = JOptionPane.showInputDialog(frame, "Insert Paper content:");

        // Δημιουργία εργασίας μέσω του RestClient
        String response = RestClient.paperCreatePost(paperTitle, username, confName, paperAbstract, paperContent);

        if (response.contains("Paper created successfully")) {
            outputLabel.setText("Paper created successfully.");
            JOptionPane.showMessageDialog(frame, "Paper '" + paperTitle + "' has been created successfully.");
        } else {
            outputLabel.setText("Error creating paper: " + response);
        }
    }
}
