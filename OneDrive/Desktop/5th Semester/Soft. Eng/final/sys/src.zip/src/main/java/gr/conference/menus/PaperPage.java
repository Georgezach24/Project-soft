package gr.conference.menus;

public class PaperPage {
	public PaperPage(String username ,String paperName){
		loadPage(username,paperName);
	}
	
	public void loadPage(String username ,String paperName)
	{
		
	}
}
