package gr.conference.menus;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UserPage {

    private JFrame frame;
    private JTextField inputField;
    private JLabel outputLabel;

    public UserPage(String usernameString) {
        loadPage(usernameString);
    }

    private void loadPage(String uString) {
        // Δημιουργία παραθύρου (JFrame)
        frame = new JFrame("User Menu");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300); // Ορισμός μεγέθους παραθύρου
        frame.setLayout(new BorderLayout());

        // Κεντρικό Panel για τις επιλογές
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(6, 1));

        // Εμφάνιση του καλωσορίσματος και επιλογών με JLabel
        JLabel welcomeLabel = new JLabel("WELCOME " + uString.toUpperCase(), JLabel.CENTER);
        JLabel label1 = new JLabel("1. User settings", JLabel.CENTER);
        JLabel label2 = new JLabel("2. Create new conference", JLabel.CENTER);
        JLabel label3 = new JLabel("3. Conference search", JLabel.CENTER);
        JLabel label4 = new JLabel("4. Exit", JLabel.CENTER);  // Πρόσθεσα επιλογή εξόδου
        outputLabel = new JLabel("", JLabel.CENTER); // Για την εμφάνιση των μηνυμάτων αποτελεσμάτων

        // Προσθήκη επιλογών στο Panel
        menuPanel.add(welcomeLabel);
        menuPanel.add(label1);
        menuPanel.add(label2);
        menuPanel.add(label3);
        menuPanel.add(label4);
        menuPanel.add(outputLabel); // Προσθήκη του label για τα αποτελέσματα

        // Προσθήκη του Panel στο κέντρο του παραθύρου
        frame.add(menuPanel, BorderLayout.CENTER);

        // Πεδίο εισαγωγής στο κάτω μέρος (input field)
        inputField = new JTextField();
        inputField.setHorizontalAlignment(JTextField.CENTER);

        // Προσθήκη ActionListener για το Enter στο πεδίο εισαγωγής
        inputField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleUserInput(inputField.getText(), uString);
                inputField.setText(""); // Καθαρισμός πεδίου μετά την είσοδο
            }
        });

        // Προσθήκη του πεδίου εισαγωγής στο κάτω μέρος του παραθύρου
        frame.add(inputField, BorderLayout.SOUTH);

        // Εμφάνιση του παραθύρου
        frame.setVisible(true);
    }

    // Μέθοδος για την επεξεργασία της εισόδου του χρήστη
    private void handleUserInput(String input, String uString) {
        int choice;
        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            outputLabel.setText("Invalid input! Please enter a valid number.");
            return;
        }

        switch (choice) {
            case 1:
                // Άνοιγμα UserSettingsPage
                outputLabel.setText("Opening User Settings...");
                new UserSettingsPage(uString); // Αν υπάρχει αυτή η κλάση
                frame.dispose();
                break;

            case 2:
                // Άνοιγμα ConferenceCreatePage
                outputLabel.setText("Opening Create New Conference...");
                new ConferenceCreatePage(uString); // Αν υπάρχει αυτή η κλάση
                frame.dispose();
                break;

            case 3:
                // Άνοιγμα ConferenceSearchPage
                outputLabel.setText("Opening Conference Search...");
                new ConferenceSearchPage(uString); // Αν υπάρχει αυτή η κλάση
                frame.dispose();
                break;

            case 4:
                // Έξοδος
                outputLabel.setText("Exiting...");
                frame.dispose();
                break;

            default:
                outputLabel.setText("Invalid choice! Please select a valid option.");
                break;
        }
    }
}
