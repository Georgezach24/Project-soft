package gr.conference.menus;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import gr.conference.usersys.RestClient;

public class RegisterPage {

    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField emailField;
    private JTextField phoneField;

    public RegisterPage() {
        initialize();
    }

    private void initialize() {
        // Δημιουργία του παραθύρου (JFrame)
        frame = new JFrame("Register");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLayout(new BorderLayout());

        // Κεντρικό Panel για τα πεδία εγγραφής
        JPanel registerPanel = new JPanel();
        registerPanel.setLayout(new GridLayout(6, 2));

        // Προσθήκη ετικετών και πεδίων εισαγωγής
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();

        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordField = new JPasswordField();

        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField();

        JLabel phoneLabel = new JLabel("Phone:");
        phoneField = new JTextField();

        // Προσθήκη των στοιχείων στο panel
        registerPanel.add(usernameLabel);
        registerPanel.add(usernameField);
        registerPanel.add(passwordLabel);
        registerPanel.add(passwordField);
        registerPanel.add(confirmPasswordLabel);
        registerPanel.add(confirmPasswordField);
        registerPanel.add(emailLabel);
        registerPanel.add(emailField);
        registerPanel.add(phoneLabel);
        registerPanel.add(phoneField);

        // Κουμπί εγγραφής
        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });

        // Προσθήκη του panel στο παράθυρο
        frame.add(registerPanel, BorderLayout.CENTER);
        frame.add(registerButton, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    // Μέθοδος για την εγγραφή του χρήστη
    private void registerUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String email = emailField.getText();
        String phone = phoneField.getText();

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(frame, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Κλήση της μεθόδου του RestClient για εγγραφή
        RestClient.registerRequest();
        RestClient.registerPost(username, password, confirmPassword, email, phone);

        JOptionPane.showMessageDialog(frame, "Registration successful!");
        
        // Επιστροφή στην αρχική σελίδα μετά την επιτυχή εγγραφή
        frame.dispose();
        new StartingScreen();
    }
}
